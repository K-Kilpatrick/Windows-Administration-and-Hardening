﻿# Get the current directory's contents
$directory = Get-ChildItem

# Iterate through each item in the directory
foreach ($item in $directory) {
    # Retrieve and display the ACL for the current item
    Get-Acl $item.FullName
}
